//
//  RKPathUtilitiesTest.m
//  RestKit
//
//  Created by Blake Watters on 10/5/12.
//  Copyright (c) 2012 RestKit. All rights reserved.
//

#import "RKTestEnvironment.h"
#import "RKPathUtilities.h"

@interface RKPathUtilitiesTest : RKTestCase

@end

@implementation RKPathUtilitiesTest


@end
