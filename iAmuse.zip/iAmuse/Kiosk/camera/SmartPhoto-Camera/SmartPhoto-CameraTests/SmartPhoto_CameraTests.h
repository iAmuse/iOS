//
//  SmartPhoto_CameraTests.h
//  SmartPhoto CameraTests
//
//  Created by Roland Hordos on 2013-05-06.
//  Copyright (c) 2013 Tandroid. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SmartPhoto_CameraTests : SenTestCase

@end
