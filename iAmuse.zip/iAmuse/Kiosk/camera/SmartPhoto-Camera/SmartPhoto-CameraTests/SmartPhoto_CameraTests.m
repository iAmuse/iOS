//
//  SmartPhoto_CameraTests.m
//  SmartPhoto CameraTests
//
//  Created by Roland Hordos on 2013-05-06.
//  Copyright (c) 2013 Tandroid. All rights reserved.
//

#import "SmartPhoto_CameraTests.h"

@implementation SmartPhoto_CameraTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SmartPhoto CameraTests");
}

@end
