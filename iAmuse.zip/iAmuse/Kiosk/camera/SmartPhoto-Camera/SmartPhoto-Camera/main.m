//
//  main.m
//  SmartPhoto Camera
//
//  Created by Roland Hordos on 2013-05-06.
//  Copyright (c) 2013 Tandroid. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NHAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NHAppDelegate class]));
    }
}
