//
//  main.m
//  SimpleHTTPServer
//
//  Created by Robert Hanson on 6/6/07.
//  Copyright Deusty Designs, LLC 2007. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
