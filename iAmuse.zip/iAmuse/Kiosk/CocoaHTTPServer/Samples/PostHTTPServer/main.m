//
//  main.m
//  PostHTTPServer
//
//  Created by Robbie Hanson on 11/20/08.
//  Copyright Deusty Designs, LLC. 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
