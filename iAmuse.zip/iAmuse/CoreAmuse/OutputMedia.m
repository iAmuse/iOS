//
//  OutputMedia.m
//  iAmuse
//
//  Created by Roland Hordos on 2014-08-03.
//  Copyright (c) 2014 iAmuse Inc. All rights reserved.
//

#import "OutputMedia.h"
#import "Photo.h"
#import "PhotoSession.h"


@implementation OutputMedia

@dynamic photo;
@dynamic session;

@end
